<template>
    <button @click="deleteAll(status)">Delete All ({{ len }})</button>
</template>

<script>
import { mapMutations } from 'vuex'

export default {
    name: 'DeleteAll',
    props: {
        len: Number,
        status: String
    },
    methods: {
        ...mapMutations([
            'deleteAll'
        ])
    },
    created() {
        console.log(this.props);
    }
}

</script>